package controller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.Voter;
import application.MainFXApp;
import application.iVoterDBConfig;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;
public class MainController {

	private MainFXApp main;
	//used to connect the main class with the controller
	public void setMain(MainFXApp mainIn)
	{
	main=mainIn;
	}
	// components in MainView.fxml
	@FXML private ComboBox<String> operationComboBox;
	@FXML private Label infoLabel;
	@FXML private Button goButton;
	// components in Insert voter tab of Insert.fxml
	@FXML private Button submitButton;
	@FXML private Button cancelButton;
	@FXML private TextField firstNameTextField,
							lastNameTextField,
							addressTextField,
							zipCodeTextField,
							countyTextField,
							stateTextField,
							phoneTextField;
	@FXML private Label statusLabel;
	@FXML private ComboBox<Integer> voterIdCombobox;
	@FXML private Pane display_pane;
	@FXML private GridPane voterInfo_gridpane_display;
	@FXML private Label firstNamelabel,
						lastNamelabel,
						addresslabel,
						zipCodelabel,
						countylabel,
						statelabel,
						phoneNumberlabel,
						statuslabel;

	// components in Update.fxml
	@FXML private Pane update_pane;
	@FXML private ComboBox<Integer> voterId_Update_Combobox;
	@FXML private Label firstName_upadte_label,
						lastName_update_label,
						address_update_label,
						zipCode_update_label,
						county_update_label,
						state_update_label,
						phoneNumber_update_label;
	@FXML private TextField firstName_upadte_textField,
					lastName_update_textField,
					address_update_textField,
					zipCode_update_textField,
					county_update_textField,
					state_update_textField,
					phoneNumber_update_textField;


	private boolean _mouseEntered_display = false;

	Stage stage;
	Scene scene;
	Parent root;

	// EventHandler +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	/** Click Event for submitting an  insert*/
	public void ClickSubmitButton(ActionEvent event) throws Exception {

		insertvoter();
	}


	/** Click Event for Canceling action */
	public void ClickCancelButton(ActionEvent event) throws Exception {

		stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

		root = FXMLLoader.load(getClass().getResource("/view/MainVoterView.fxml"));
		scene = new Scene(root);
		stage.setScene(scene);

	}

	/** Selection Event for select item in the ComboBox */
	public void selectComboBox(ActionEvent event) throws Exception {

		if(event.getSource() == operationComboBox && operationComboBox.getValue() != null){
			goButton.setDisable(false);
			switch (operationComboBox.getValue()) {

			case "Display_Voter":
				infoLabel.setText("Status: Display operation selected");
				break;
			case "Add_Voter":
				infoLabel.setText("Status: Insert operation selected");
				break;
			case "Update_Voter":
				infoLabel.setText("Status: Update operation selected");
				break;
			default:
				infoLabel.setText("Status: No operation selected.");
				break;
			}
		} else if(event.getSource() == voterIdCombobox ){

			// display info of voter. display location: display_pane
			this._displayvoterInfo(voterIdCombobox.getValue());

		} else if(event.getSource() == voterId_Update_Combobox){

			// display info of voter, related to voterId. display location: update_pane
			this._displayvoterToUpdatePane(voterId_Update_Combobox.getValue());
		}

	}

	/**Event to update voter info
	 * @throws Exception */
	public void Clicksubmit_update_button(ActionEvent event) throws Exception {
		System.out.println("start updatting the voter record");

		String firstName, lastName, address, zipCode, county,state, phoneNumber;

		firstName = firstName_upadte_textField.getText();
		lastName = lastName_update_textField.getText();
		address = address_update_textField.getText();
		zipCode = zipCode_update_textField.getText();
		county = county_update_textField.getText();
		state = state_update_textField.getText();
		phoneNumber = phoneNumber_update_textField.getText();

		// validate values
		if (firstName == null || firstName == "" || firstName.trim().isEmpty()) {
			throw new Exception("invalid First Name.");
		}

		/*
		if (lastName == null || lastName == "" || lastName.trim().isEmpty()) {
			throw new Exception("invalid Last Name.");
		}
		if (address == null || address == "" || address.trim().isEmpty()) {
			throw new Exception("invalid Address.");
		}
		if (zipCode == null || zipCode == "" || zipCode.trim().isEmpty()) {
			throw new Exception("invalid zip Code.");
		}
		if (state == null || state == "" || state.trim().isEmpty()) {
			throw new Exception("invalid State.");
		}
		if (county == null || county == "" || county.trim().isEmpty()) {
			throw new Exception("invalid County.");
		}
		if (phoneNumber == null || phoneNumber == "" || phoneNumber.trim().isEmpty()) {
			throw new Exception("invalid Phone Number.");
		}
*/
		// store data into a new voter object

		Voter voter = new Voter();
		voter.setvoterId(voterId_Update_Combobox.getValue());
		voter.setFirstName(firstName);
		voter.setLastName(lastName);
		voter.setAddress(address);
		voter.setZipCode(zipCode);
		voter.setCounty(county);
		voter.setState(state);
		voter.setPhoneNumber(phoneNumber);

		String query = "update voter set " +
						"firstName = ?, lastName = ?, address = ?, county = ?, state = ?,zipcode = ?, phone = ?"
				+ "where voterId = ?";

		try(
				Connection conn = iVoterDBConfig.getConnection();
				PreparedStatement updateprofile = conn.prepareStatement(query);
		){
			updateprofile.setString(1, voter.getFirstName());
			updateprofile.setString(2, voter.getLastName());
			updateprofile.setString(3, voter.getAddress());
			updateprofile.setString(4, voter.getCounty());
			updateprofile.setString(5, voter.getState());
			updateprofile.setString(6, voter.getZipCode());
			updateprofile.setString(7, voter.getPhoneNumber());
			updateprofile.setInt(8, voter.getvoterId());
			updateprofile.executeUpdate();


		}catch(SQLException e){
			iVoterDBConfig.displayException(e);
			statuslabel.setText("Status: update failed due to: " + e.getMessage());
		}

	}

	private void _displayvoterToUpdatePane(Integer id)throws SQLException{

		// get from table voter, to labels

		Voter voter = _getRowByIdFromvoterTable(id);
		firstName_upadte_label.setText(voter.getFirstName());
		lastName_update_label.setText(voter.getLastName());
		address_update_label.setText(voter.getAddress());
		county_update_label.setText(voter.getCounty());
		state_update_label.setText(voter.getState());
		zipCode_update_label.setText(voter.getZipCode());
		phoneNumber_update_label.setText(voter.getPhoneNumber());

		// write to textfields

		firstName_upadte_textField.setText(voter.getFirstName());
		lastName_update_textField.setText(voter.getLastName());
		address_update_textField.setText(voter.getAddress());
		county_update_textField.setText(voter.getCounty());
		state_update_textField.setText(voter.getState());
		zipCode_update_textField.setText(voter.getZipCode());
		phoneNumber_update_textField.setText(voter.getPhoneNumber());


	}

	private void _displayvoterInfo(Integer id) throws SQLException{

		// get from table voter

		Voter voter = _getRowByIdFromvoterTable(id);
		firstNamelabel.setText(voter.getFirstName());
		lastNamelabel.setText(voter.getLastName());
		addresslabel.setText(voter.getAddress());
		countylabel.setText(voter.getCounty());
		statelabel.setText(voter.getState());
		zipCodelabel.setText(voter.getZipCode());
		phoneNumberlabel.setText(voter.getPhoneNumber());
	}

	/** Get one row from voter table
	 * @throws SQLException */
	private Voter _getRowByIdFromvoterTable(int voterId) throws SQLException{
		String SQLQuery = "select * from voter where voterId = ?";
		ResultSet rs = null;

		try(
				Connection conn = iVoterDBConfig.getConnection();
				PreparedStatement displayprofile = conn.prepareStatement(SQLQuery);
		){
			displayprofile.setInt(1, voterId);
			rs = displayprofile.executeQuery();

			// check to see if receiving any data
			if(rs.next()){
				Voter voter = new Voter();
				voter.setvoterId(voterId);
				voter.setFirstName(rs.getString("firstName"));
				voter.setLastName(rs.getString("lastName"));
				voter.setAddress(rs.getString("address"));
				voter.setCounty(rs.getString("county"));
				voter.setState(rs.getString("state"));
				voter.setZipCode(rs.getString("zipcode"));
				voter.setPhoneNumber(rs.getString("phone"));
				return voter;
			}else{
				return null;
			}
		}catch(SQLException ex){
			iVoterDBConfig.displayException(ex);
			return null;
		}finally{
			if(rs != null){
				rs.close();
			}
		}
	}


	/**MouseEnter event to retrieve voter id  from voter table and inject to combobox*/
	public void mouseenter_pane(MouseEvent event)throws Exception{

		if(!this._mouseEntered_display && event.getSource() == display_pane){
			this._mouseEntered_display = true;

			// generate items(voter_id) for voterIdCombobox and populate the id into the combobx
			voterIdCombobox.getItems().clear();
			voterIdCombobox.getItems().addAll(getFromOneColumnOfTable("voterId", "voter"));

		}else if (!this._mouseEntered_display && event.getSource() == update_pane ){

			this._mouseEntered_display = true;
			//voterId_Update_Combobox.getItems().clear();
			voterId_Update_Combobox.getItems().addAll(getFromOneColumnOfTable("voterId", "voter"));
		}

	}

	/** Click Event for ExecuteButton */
	public void ClickGoButton(ActionEvent event) throws Exception {

		if (operationComboBox.getValue() != null) {

			stage = (Stage) operationComboBox.getScene().getWindow();

			switch (operationComboBox.getValue()) {
				case "Display_Voter":
					root = FXMLLoader.load(getClass().getResource("/view/displayVoters.fxml"));
					scene = new Scene(root);
					stage.setScene(scene);
					break;

				case "Add_Voter":
					root = FXMLLoader.load(getClass().getResource("/view/addVoter.fxml"));
					scene = new Scene(root);
					stage.setScene(scene);
					break;

				case "Update_Voter":
					root = FXMLLoader.load(getClass().getResource("/view/updateVoter.fxml"));
					scene = new Scene(root);
					stage.setScene(scene);
					break;

				default:
					break;

			}
		}
	}



	/** Insert a row to voter table of Database */
	private void insertvoter() throws SQLException {

		String query = "insert into voter " + "(firstName, lastName, address, zipcode, county, state,phone)"
				+ "values(?,?,?,?,?,?,?)";
		ResultSet keys = null;

		try (Connection conn = iVoterDBConfig.getConnection();
				PreparedStatement insertprofile = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);) {

			// get values
			String firstName, lastName, address, zipCode,state,county,  phoneNumber;
			firstName = firstNameTextField.getText();
			lastName = lastNameTextField.getText();
			address = addressTextField.getText();
			zipCode = zipCodeTextField.getText();
			county = countyTextField.getText();
			state = stateTextField.getText();
			phoneNumber = phoneTextField.getText();

			// value validation
			if (firstName == null || firstName == "" || firstName.trim().isEmpty()) {
				throw new Exception("invalid first name.");
			}
			/*
			if (lastName == null || lastName == "" || lastName.trim().isEmpty()) {
				throw new Exception("invalid last name.");
			}
			if (address == null || address == "" || address.trim().isEmpty()) {
				throw new Exception("invalid address.");
			}
			if (state == null || state == "" || state.trim().isEmpty()) {
				throw new Exception("invalid state");
			}
			if (county == null || county == "" || county.trim().isEmpty()) {
				throw new Exception("invalid county code.");
			}
			if (zipCode == null || zipCode == "" || zipCode.trim().isEmpty()) {
				throw new Exception("invalid zip code.");
			}
			if (phoneNumber == null || phoneNumber == "" || phoneNumber.trim().isEmpty()) {
				throw new Exception("invalid phone number.");
			}
*/
			//
			Voter voter = new Voter();
			voter.setFirstName(firstName);
			voter.setLastName(lastName);
			voter.setAddress(address);
			voter.setCounty(county);
			voter.setState(state);
			voter.setZipCode(zipCode);
			voter.setPhoneNumber(phoneNumber);

			insertprofile.setString(1, voter.getFirstName());
			insertprofile.setString(2, voter.getLastName());
			insertprofile.setString(3, voter.getAddress());
			insertprofile.setString(4, voter.getCounty());
			insertprofile.setString(5, voter.getState());
			insertprofile.setString(6, voter.getZipCode());
			insertprofile.setString(7, voter.getPhoneNumber());

			// get the number of return rows
			int affectedRow = insertprofile.executeUpdate();

			if (affectedRow == 1) {
				keys = insertprofile.getGeneratedKeys();
				keys.next();
				int newKey = keys.getInt(1);
				voter.setvoterId(newKey);

				// when operation done to clear the form controls

				firstNameTextField.setText(null);
				lastNameTextField.setText(null);
				addressTextField.setText(null);
				countyTextField.setText(null);
				zipCodeTextField.setText(null);
				stateTextField.setText(null);
				phoneTextField.setText(null);
				statusLabel.setText("Status: a voter record is inserted >> (" + voter.getvoterId() + ", "
						+ voter.getFirstName() + " " + voter.getLastName() + ")");
			}

		} catch (Exception e) {
			statusLabel.setText("Status: operation failed due to: " + e.getMessage());
		} finally {
			if (keys != null) {
				keys.close();
			}
		}
	}

	/** Retrieve all integer data as ArrayList from one column in one table */
	public ArrayList<Integer> getFromOneColumnOfTable(String columnName, String tableName) {
		String query = "SELECT " + columnName + " FROM " + tableName;
		ArrayList<Integer> array = new ArrayList<Integer>();

		try (Connection conn = iVoterDBConfig.getConnection();
				Statement sm = conn.createStatement();
				ResultSet rs = sm.executeQuery(query);) {
			while (rs.next()) {
				array.add(rs.getInt(columnName));
			}
			return array;
		} catch (SQLException ex) {
			iVoterDBConfig.displayException(ex);
			return null;
		}
	}

}
